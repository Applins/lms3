function Footer() {
    return <footer className="custom-bg-color bg-dark text-white text-center p-3">
      <div className="container">
        <p>© 2023 Robotics Championship</p>
      </div>
    </footer>;
  }

  export default Footer;