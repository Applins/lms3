var mockTeamData = {
    app: {
     sortCol:"name",
     sortDir:"asc",
     filterStr:""
  
    },
    data:[
        {
            id: 1,
            name: 'Husky Robotics',
            coachName: 'Mark Musk',
            coachPhone: '801-555-2525',
            coachEmail: 'muskyhusky@gmail.com',
          },
          {
            id: 2,
            name: 'Lion Force',
            coachName: 'Mufasa Lion',
            coachPhone: '915-357-1257',
            coachEmail: 'mufafafa@gmail.com',
          },
          {
            id: 3,
            name: 'Autobots',
            coachName: 'Optimus Prime',
            coachPhone: '101-110-0011',
            coachEmail: 'optimus@prime.com',
          },
    ]
        
}  
export default mockTeamData